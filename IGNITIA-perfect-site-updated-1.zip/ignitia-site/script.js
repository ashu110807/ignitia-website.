const members=[
['President','To be appointed'],['Vice President','Ashutosh'],['EVM Head','Aahan'],['PR & Sponsorship Head','To be appointed'],['Marketing Head','To be appointed'],['Tech Head','Garvit'],['Graphic Head','To be appointed'],['Social Media Head','To be appointed'],['Content & Editorial Head','To be appointed']
];
const grid=document.querySelector('#teamGrid');
grid.innerHTML=members.map(([role,name])=>`<article class="member"><div class="avatar">${name==='To be appointed'?'?':name[0]}</div><h4>${name}</h4><p>${role}</p></article>`).join('');
document.querySelectorAll('a[href^="#"]').forEach(a=>a.addEventListener('click',e=>{const t=document.querySelector(a.getAttribute('href'));if(t){e.preventDefault();t.scrollIntoView({behavior:'smooth'})}}));