# IGNITIA Fest Society Website

Upload `index.html`, `style.css`, and `script.js` to your GitHub repository and deploy it with Vercel or GitHub Pages.

Before publishing, change `ignitia@example.com` in `index.html` and replace the sample team entries in `script.js`.

The public Core Team UI is ready for connection to an owner/admin backend. For real editable administration, add authentication + a database (for example Supabase/Firebase) without putting secret keys in frontend code.
